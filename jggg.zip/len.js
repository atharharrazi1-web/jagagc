const fs = require("fs");
const chalk = require("chalk");
const moment = require("moment-timezone");

global.grup = "";
global.ig = "-";
global.thumb = fs.readFileSync("./data/image/thumb.jpg");
global.email = "";
global.region = "";

global.owner = ["6285138983554"];
global.developer = ["6285138983554"];
global.bot = ["62881010401983"];
global.ownername = "aleyaa";
global.developername = "aleyaa";
global.botname = "aleyaa";
global.emoji = "🕊️";
global.packname = "aleya";
global.author = `aleyaa`;
// ------------------------------- [ DIGIFLAZZ ] -------------------------------------//
global.priceRegular = 5; // 5%
global.priceVip = 3; // 3%
global.priceMvip = 1; // 1%
// ------------------------------- [ KEBSOS ] -------------------------------------//
global.priceRegularKebsos = 20; // 20%
global.priceVipKebsos = 10; // 10%
global.priceMvipKebsos = 8; // 8%

global.keyopenai = "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";
global.ibeng = "Yl4h5x9wiA";

global.api = {
  xterm: {
    url: "https://ai.xterm.codes",
    key: "Bell409",
  },
};

global.xprefix = ".";

global.domain = "-";
global.apikey = "-"; // Plta
global.capikey = "-"; // Pltc
global.eggsnya = "15";
global.location = "1";

global.prefa = ["", "!", ".", ",", "🐤", "🗿"];
global.sessionName = "session";
global.anticall = true;
global.autobakcup = true;

global.mess = {
  success: "*selesai*",
  admin: "⚠️ *fitur khusus admin group!*",
  botAdmin:
    "⚠️ *fitur ini hanya bisa digunakan ketika bot menjadi admin group!*",
  owner: "⚠️ *fitur khusus owner!*",
  creator: "⚠️ *fitur Khusus Creator!*",
  prem: "⚠️ *fitur khusus premium!*",
  group: "⚠️ *fitur ini hanya nisa digunakan di group chat!*",
  wait: "📦 *Dalam Proses*",
  error: "⚠️ *error, coba lagi di lain waktu*",
  link: "⚠️ *itu bukan link yang benar*",
};

global.limitawal = {
  premium: 100000,
  free: 50,
};

global.multiplier = 1000;

global.text_sewa = "";
global.text_ppj = "";

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.green(`📑  Update : ${__filename}`));
  delete require.cache[file];
  require(file);
});
